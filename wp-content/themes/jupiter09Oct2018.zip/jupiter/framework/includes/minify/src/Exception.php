<?php

namespace MatthiasMullie\Minify;

/**
 * @author Matthias Mullie <minify@mullie.eu>
 */
class Exception extends \Exception
{
}
